using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TipsToPlay : MonoBehaviour
{
    public void Tips()
    {
        SceneManager.LoadScene("1");
    }

}
